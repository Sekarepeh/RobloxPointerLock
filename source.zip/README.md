# Roblox Pointer Lock (LSPosed module)

Forces Android's native `View.requestPointerCapture()` inside Roblox
(`com.roblox.client`) whenever an Activity regains window focus. This
does **not** touch Roblox's own control bindings, keymaps, or scripts -
it only asks Android's system to hide the cursor and switch to relative
mouse-delta reporting, which is the same mechanism a real FPS PC client
uses.

## Build option A: from your phone via GitHub Actions (no PC needed)

1. Create a **new empty GitHub repo** (from the GitHub app, or github.com
   in browser).
2. Push this folder's contents into it. From Termux:
   ```
   cd RobloxPointerLock
   git init
   git add .
   git commit -m "init"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo>.git
   git push -u origin main
   ```
3. Go to the repo on GitHub > **Actions** tab. The "Build APK" workflow
   runs automatically on push (or trigger it manually via
   "Run workflow").
4. When it finishes (green check), open the workflow run > **Artifacts**
   section > download `RobloxPointerLock-apk` (a zip containing the
   APK).
5. Unzip on your phone, install the APK.

This does the actual compiling on GitHub's servers, so your phone never
needs Android Studio or the SDK.

## Build option B: Android Studio (if you have a PC)

1. Open this folder as a project in **Android Studio** (Giraffe/Koala or
   newer, with Android Gradle Plugin 8.1+ and JDK 17 installed).
2. Let Gradle sync. It pulls `de.robv.android.xposed:api:82` from
   `https://api.xposed.info/`, which is declared in the root
   `build.gradle`.
3. Build > Build Bundle(s)/APK(s) > Build APK(s), or run:
   ```
   ./gradlew assembleRelease
   ```
4. Grab the APK from `app/build/outputs/apk/release/app-release.apk`.

## Install

1. Copy the APK to your phone and install it normally (allow "install
   unknown apps" if prompted).
2. Open **LSPosed Manager** > Modules > enable "Roblox Pointer Lock".
3. Tap the module, confirm its scope includes `com.roblox.client`
   (already set by default via `xposed_scope`).
4. Reboot, or use LSPosed's soft-reboot / "Force stop" on Roblox so the
   hook takes effect.
5. Force-stop and relaunch Roblox, connect your mouse, and join a game
   that uses camera-look controls.

## Debugging if it doesn't work

Open LSPosed Manager > Logs (or `adb logcat | grep RobloxPointerLock`)
while playing. You should see:
```
[RobloxPointerLock] requestPointerCapture() called on <ActivityName>
[RobloxPointerLock] onPointerCaptureChange -> true on <ViewName>
```
If capture is granted (`true`) but the camera still doesn't move with
the mouse, that means Roblox's own renderer/view isn't listening for
`onCapturedPointerEvent` - in that case the fix has to live inside
Roblox's own binary, which this module can't patch. If you never see
`requestPointerCapture() called` at all, the hook didn't attach - check
that the module is enabled, scoped to `com.roblox.client`, and that
Roblox was fully force-stopped and relaunched after enabling it.

## Important caveats

- **This is genuinely experimental.** Android's pointer capture only
  works if the *target* app also reacts to captured pointer events
  internally. Roblox's mobile client may or may not do this - the hook
  can request capture, but can't guarantee Roblox interprets the
  resulting motion events correctly for camera look.
- **Account risk:** Roblox runs anti-cheat/anti-tamper systems that can
  detect root and Xposed/LSPosed on the device. Using this module could
  get flagged or result in action against your account, since it's
  outside Roblox's supported client behavior. Use at your own risk,
  ideally test on a throwaway/alt account first.
