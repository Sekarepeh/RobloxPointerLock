package com.example.robloxpointerlock;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class DummyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("Roblox Pointer Lock module active.\n\n"
                + "Enable this module in LSPosed Manager, make sure "
                + "'com.roblox.client' is checked in its scope, then "
                + "reboot (or use LSPosed's soft-reboot).\n\n"
                + "Check LSPosed Manager > Logs while Roblox is running "
                + "to confirm requestPointerCapture() is firing.");
        tv.setPadding(48, 96, 48, 48);
        tv.setTextSize(16);
        setContentView(tv);
    }
}
