package com.example.robloxpointerlock;

import android.app.Activity;
import android.view.View;
import android.view.Window;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TARGET_PACKAGE = "com.roblox.client";
    private static final String TAG = "[RobloxPointerLock]";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) {
            return;
        }

        XposedBridge.log(TAG + " loaded into " + lpparam.packageName);

        // Every time any Activity in the app regains window focus, try to
        // force native Android pointer capture (hides cursor, reports
        // relative mouse deltas). This does NOT touch Roblox's own input
        // handling / keybinds - it only asks Android to capture the pointer.
        XposedHelpers.findAndHookMethod(
                Activity.class,
                "onWindowFocusChanged",
                boolean.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        boolean hasFocus = (boolean) param.args[0];
                        if (!hasFocus) {
                            return;
                        }

                        Activity activity = (Activity) param.thisObject;
                        try {
                            Window window = activity.getWindow();
                            if (window == null) return;

                            View decorView = window.getDecorView();
                            if (decorView == null) return;

                            // requestPointerCapture() only works once the
                            // view hierarchy actually has window focus.
                            decorView.post(() -> {
                                try {
                                    if (decorView.hasWindowFocus()) {
                                        decorView.requestPointerCapture();
                                        XposedBridge.log(TAG + " requestPointerCapture() called on "
                                                + activity.getClass().getName());
                                    }
                                } catch (Throwable inner) {
                                    XposedBridge.log(TAG + " post-runnable error: " + inner);
                                }
                            });
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + " failed to request pointer capture: " + t);
                        }
                    }
                }
        );

        // Log capture state changes AND auto re-request capture whenever it
        // gets released (e.g. after a right-click that Roblox treats as a
        // "release cursor" action). This avoids having to manually back out
        // to Settings and back to re-lock the cursor.
        try {
            XposedHelpers.findAndHookMethod(
                    View.class,
                    "onPointerCaptureChange",
                    boolean.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            boolean hasCapture = (boolean) param.args[0];
                            View view = (View) param.thisObject;
                            XposedBridge.log(TAG + " onPointerCaptureChange -> " + hasCapture
                                    + " on " + view.getClass().getName());

                            if (!hasCapture) {
                                // Retry a few times with increasing delay -
                                // a single attempt can lose a race with
                                // whatever caused the release.
                                long[] delays = {150L, 350L, 600L, 1000L};
                                for (long delay : delays) {
                                    view.postDelayed(() -> {
                                        try {
                                            if (view.hasWindowFocus()) {
                                                view.requestPointerCapture();
                                                XposedBridge.log(TAG + " auto re-requested capture on "
                                                        + view.getClass().getName() + " (delay " + delay + "ms)");
                                            }
                                        } catch (Throwable inner) {
                                            XposedBridge.log(TAG + " auto re-request failed: " + inner);
                                        }
                                    }, delay);
                                }
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + " could not hook onPointerCaptureChange: " + t);
        }
    }
}
